import math


def main():
    prob_values = [4/9, 1/3, 1/9, 1/9]
    radix = 2

    result = 0
    for value in prob_values:
        result += value * -math.log(value, radix)

    print(result)
    print("rounded", round(result, 3))


if __name__ == '__main__':
    main()

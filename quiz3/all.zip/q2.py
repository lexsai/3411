import math


def main():
    m_matrix = [
        [0.75, 0.35],
        [0.25, 0.65]
    ]
    p_vec = [
        500/857,
        357/857,
    ]
    symbols = 2

    assert len(m_matrix) == len(p_vec)
    result = 0
    for i in range(len(m_matrix)):
        assert len(m_matrix) == len(m_matrix[i])
        col_info = 0
        for j in range(len(m_matrix)):
            col_info += m_matrix[j][i] * -math.log(m_matrix[j][i], symbols)
        result += col_info * p_vec[i]

    print(result)
    print("rounded", round(result, 2))


if __name__ == '__main__':
    main()

def main():
    value = 28
    mod = 41

    print(pow(value, -1, mod))


if __name__ == '__main__':
    main()

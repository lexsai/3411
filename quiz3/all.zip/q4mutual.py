def main():
    h_A = 0.71
    h_B = 0.2
    h_AB = 0.73

    h_B_A = h_AB - h_A
    print(h_B - h_B_A)
    print("rounded", round(h_B - h_B_A, 2))


if __name__ == '__main__':
    main()
